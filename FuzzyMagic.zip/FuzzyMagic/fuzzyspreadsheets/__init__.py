__version__ = "1.0.0"
from .generate import generate_spreadsheet, generate_spreadsheets
from .model import merge_spreadsheets, detect_duplicates

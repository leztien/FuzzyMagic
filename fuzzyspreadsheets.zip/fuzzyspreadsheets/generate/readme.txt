This folder contains building blocks for the data generating functions.
